import React from 'react'
import './App.css'
import MoviesData from "./components/MoviesData"
import Movie from "./components/Movie"
import Buttons from "./components/Buttons"


function App() {

  const MovieComponents = MoviesData.map(movie => {
    return (
      <Movie key={movie.id} imageURL={movie.imageURL} title={movie.title} summary={movie.summary} rating={movie.rating}/>
    )
})


  return (
    <div className="App">
          {MovieComponents}
          <Buttons />
    </div>
  );
}

export default App;
