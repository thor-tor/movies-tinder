import React from "react";


function Movie(props){
    return(
        <div className="movieContainer">
            <h2>{props.title}</h2>
            <img alt="movie poster" className="moviePoster" src={props.imageURL}></img>
            <p>{props.summary}</p>
            <p>({props.rating}/10)</p>
        </div>
    )
}

export default Movie