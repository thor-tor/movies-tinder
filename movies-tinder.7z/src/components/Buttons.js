import React from "react";

// const addMovie = () =>{
//     MovieComponents.splice(0, 1);
// }

// const removeMovie = () =>{
//     MovieComponents.splice(0, 1);
// }

function Buttons(){
    return(
        <div>
            <button className="acceptButton" > Accept</button>
            <button className="rejectButton" > Reject</button>
        </div>
    )
}

export default Buttons;